%% Workshop Task Notes for MATLAB Data Manipulation & Processing-08/05/18

%% 1. Importing DATA into MATLAB
% Task - Make sure your data files and this script are in the 
% same folder and the folder is set to your current folder in the workspace

%% 1.1 Importing in Table Form
%% Task 1-import the 'number-of-teachers-across-education-levels.csv' file
% using the readtable function

% Observe the data and look at the different headings
% Observe what happemned to the empty fields of the data
%% Task 2-access specific variables using the dot notation and save them in different variables(Entity, Year & Number of teachers in Tertiary Education)

%% Task 3-Create a scatter plot for teacher numbers across years vs. Number of Tertiary education teachers

%% Task 4-Try importing the 'pupil-teacher-ratio-for-primary-education-by-country.csv' file

% Observe the header of the created table and the first row, Why has this happened? 
% You can look at the previous document in txt form to see the difference.

%% Task 5-Change the HeaderLines property to correct the import format

%% Task 6-Try importing the 'share-of-teachers-in-primary-education-who-are-trained.csv' file

% observe the lines where the country name changes for some of the topmost countries.
% What are the common characters preceding every extra line

%% Task 5-Change the CommentStyle property to correct the import format

%% 1.2 Datastores
%% Task 1- Clear all of the imported data and created variables from the workspace again

%% Task 2- Create a datastore object referencing the 'number-of-teachers-across-education-levels.csv' file

% Observe the properties listed in the command window for the 
% datastore object or click on the variable to observe the full set of parameters
%% Task 3-Use the preview function to observe the format of the first few lines showing what the imported data will look like

% Observe the header lines of the table, first few lines, any missing values etc
%% Task 4-create two other datastore objects for the 'pupil-teacher-ratio-for-primary-education-by-country.csv' and 'share-of-teachers-in-primary-education-who-are-trained.csv' files
% Dont forget to change the relevant parameters as we did earlier

% preview both datastore objects to confirm that the import is correct

%% Task 5-create a datastore object which references all 3 files 

%% Task 6-Read from the datastore object referencing the 'number-of-teachers-across-education-levels.csv' file

%% Task 7-Change the readsize property and observe the result

%% Task 8-Try the readall and reset functions on the datastore that contains references to all 3 files

%% 2. Cleaning Data
% Task- Clear all of the imported data and created variables from the workspace again and import each file using either readtable or datastore objects

%% 2.1 Working Around the NaN Values
%% Task 1-Try taking the mean of the number of tertiary teachers across the years and countries

% observe the result
%% Task 2-Try using the omitnan property of the mean function to find the mean

% observe the result
%% Task 3-Every array should be equal to itself, try the isequal funcion to check if the tertiary teacher number array is equal to itself

%% Task 4-isequal does not have a omitnan property, try the isequaln function

%% 2.2 Locating and Eliminating Missing Data
%% Task 1-use isnan to obtain the NaN value indexes in the Tertiary teacher number array as a logical array and assign it to a variable

% Compare if the result is as expected
%% Task 2-Use the nnz (number of non-zero elements) function to see how many NaN values are in the array

%% Task3-Replace the NaN values with an identifiable value 

%% Task 4-Using the same index variable completely remove the NaN values

% Observe the size of the remaining values
%% 3. Managing Data
% Task-Extract the Entity values from the number of teachers across levels
% dataset
%% 3.1 Categorical Data
%% Task 1- Observe the memory space allocated for the Entity values by using the whos function

%% Task 2-Change the variable into a categorical array using the categorical function and observe the memory space again

%% Task 3-Determine the categories in the categorical entities array using the categories function

% Observe the output of the function
%% Task 4-Remove the 'World' category from the list using the setdiff (difference of sets function)

%% Task 5-Use mergecats to merge several categories into a single one "Europe and Central Asia, Europe and Central Asia (all income levels)"

%% 3.2 Discretizing Data
%% Task 1-Obtain the number of primary teachers into a another variable from the teachers across levels dataset

%% Task 2-Create evels and borders to determine bin intervals (create 4 bins/5 levels)

%% Task 3-Use the discretize function to place each value into a bin

%observe the output
%% Task 4-Select 4 category names in a cell array as we have 4 bins

%% Task 5-Use the categorical option of the discretize function to assign categories to the bins

%observe the output
%% Task 6-Since the categories relate to numerical values you can search for the number of elements that are below a certain categorical value
% Find the number of elements that have a teacher number categorised as below par or less

% How would you get the indices of the variables that had teachers less than below par?
%% 4 Analyzing Groups in Data
% Task- Clear the workspace and import the 'number-of-teachers-across-education-levels.csv' data file using either readtable or by creating a datastore

%% Task 1-Use the "findgroups" function to find the different groups of countries in the data

%% Task 2-To obtain the values of each groupnumber, another output can be assigned to the "findgroups" function

%Observe the number of elements in both outputs
%% Task 3-To obtain the number of elements in each group you can use the "histcounts" function. Find how many elements are in each group.
%make sure the second input (bin number) is equal to the number of groups

%% Task 4-Do the same procedure to determine the groups in the years of observation across all countries

%% Task 5-Try to find groups (using findgroups) depending on both the country names and the year of observation
% Consider how many outputs you should have

%% Task 6-Use "splitapply" to apply a function to only a group of data. Lets say you want to take the mean value of all the teacher numbers everywhere in each year
%Take the mean of every value obtained for the number of teachers in thirtiary education in each year around the world using splitapply

%% Task 7-Try doing the same for each country

% What is the country with the lowest mean teacher number in tertiary education across the years
%% Task 8-Finally lets visualise our group data using a bar chart using the bar function

%% Hope this was a useful tutorial for you. You are invited to join the Visualization Meetup to expand on creating beautiful graphs and data presentations
%% It will be held on the 21st of May at 2pm in the same place

%% Thanks for joining...